package exemplojavagrafo;

import java.util.Scanner;
//Alunos:
//Arthur Gaspare Camzano
//Isabella Ferreira Gomes da Silva

public class ExemploJavaGrafo {

    public static void main(String[] args) {
       int nVertices, nArestas, origem, destino;
        Scanner sc = new Scanner(System.in);

        System.out.println("Informe o número de vértices do grafo:");
        nVertices = sc.nextInt();

        System.out.println("Informe o número de arestas do grafo:");
        nArestas = sc.nextInt();

        Grafo g = new Grafo(nVertices, nArestas);

        System.out.println("\n--- Adicionando as arestas do grafo ---");
        for (int i = 0; i < nArestas; i++) {
            System.out.println("\nAresta " + (i + 1));
            System.out.print("Informe o vértice de origem: ");
            origem = sc.nextInt();
            System.out.print("Informe o vértice de destino: ");
            destino = sc.nextInt();
            g.adicionarAresta(origem - 1, destino - 1); // ajusta pra índice começar em 0
        }

        System.out.println("\n--- MATRIZ DE ADJACÊNCIA ---");
        g.exibeMatriz();

        System.out.println("\n--- GRAUS DOS VÉRTICES ---");
        for (int i = 0; i < nVertices; i++) {
            System.out.println("VÉRTICES " + (i + 1) + " -> Grau: " + g.getGrau(i));
        }

        System.out.println("\n--- OUTRAS INFORMAÇÕES ---");
        System.out.println("QTDE LAÇOS: " + g.getQuantidadeLacos());
        System.out.println("QTDE ARESTAS PARALELAS: " + g.getQuantidadeArestasParalelas());
    }
    
}
