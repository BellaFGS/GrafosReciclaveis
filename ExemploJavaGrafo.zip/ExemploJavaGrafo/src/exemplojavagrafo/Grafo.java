/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplojavagrafo;

public class Grafo {
    private int numVertices;
    private int numArestas;
    private int [][] matrizAdjacencia;
    
    public Grafo (int numVertices, int numArestas){
        this.numVertices = numVertices;
        this.numArestas = numArestas;
        matrizAdjacencia = new int [numVertices][numVertices];
        
        for(int linha = 0; linha<numVertices; linha++){
            for(int coluna = 0; coluna<numVertices; coluna++){
                matrizAdjacencia[linha][coluna]=0;
            }
        }
    }
    
    
    public void adicionarAresta(int vOrigem, int vDestino){
        matrizAdjacencia[vOrigem][vDestino]+=1;
        matrizAdjacencia[vDestino][vOrigem]+=1;
        System.out.println("╰(*°▽°*)╯");

    }
    
    public void exibeMatriz(){
        for(int linha = 0; linha<numVertices; linha++){
            for(int coluna = 0; coluna<numVertices; coluna++){
                System.out.print(matrizAdjacencia[linha][coluna] + " "); 
            }
            System.out.print("\n");
        }
    }
    
    public int getGrau(int vertice){
        int grau = 0;
        for(int i = 0; i < numVertices; i++){
            if(i == vertice){
                // laço conta como 2 no grau
                grau += 2 * matrizAdjacencia[vertice][i];
            } else {
                grau += matrizAdjacencia[vertice][i];
            }
        }
        return grau;
    }

    
    public int getQuantidadeLacos(){
        int lacos = 0;
        for(int i = 0; i < numVertices; i++){
            lacos += matrizAdjacencia[i][i];
        }
        return lacos;
    }
    public int getQuantidadeArestasParalelas(){
        int paralelas = 0;
        for(int i = 0; i < numVertices; i++){
            for(int j = i+1; j < numVertices; j++){ // só metade superior
                if(matrizAdjacencia[i][j] > 1){
                    paralelas += (matrizAdjacencia[i][j] - 1);
                }
            }
        }
        return paralelas;
    }
}
